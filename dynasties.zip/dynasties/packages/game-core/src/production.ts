import {
  BASE_CAP,
  BASE_RATE_PER_HOUR,
  CAP_GROWTH,
  FLOOR_CAP,
  FLOOR_RATE_PER_HOUR,
  MAX_LEVEL,
  RATE_GROWTH,
} from './config.ts';
import type { BaseKind, BaseState, Resource, Stock, Treasury } from './types.ts';

const HOUR_MS = 3_600_000;
export const RESOURCES: Resource[] = ['food', 'ammo', 'troops'];

export function emptyStock(): Stock {
  return { food: 0, ammo: 0, troops: 0 };
}

export function ratePerHour(kind: BaseKind, level: number, res: Resource): number {
  const base = BASE_RATE_PER_HOUR[kind][res];
  if (!base) return 0;
  return base * Math.pow(RATE_GROWTH, level - 1);
}

export function capFor(kind: BaseKind, level: number, res: Resource): number {
  const base = BASE_CAP[kind][res];
  if (!base) return 0;
  return Math.floor(base * Math.pow(CAP_GROWTH, level - 1));
}

/** Total income per hour: the guaranteed floor plus every base. */
export function totalRates(bases: BaseState[]): Stock {
  const out = { ...FLOOR_RATE_PER_HOUR };
  for (const b of bases) for (const r of RESOURCES) out[r] += ratePerHour(b.kind, b.level, r);
  return out;
}

/** Total storage: the guaranteed floor cap plus every base. */
export function totalCaps(bases: BaseState[]): Stock {
  const out = { ...FLOOR_CAP };
  for (const b of bases) for (const r of RESOURCES) out[r] += capFor(b.kind, b.level, r);
  return out;
}

/**
 * Lazily bring a treasury up to `now`. Production is linear in elapsed time and
 * clamped to the cap; stock already above the cap (e.g. received by trade) is never reduced.
 * Offline players are handled for free: nothing ticks, the elapsed time is simply applied.
 */
export function settleCountry(t: Treasury, bases: BaseState[], now: number): Treasury {
  const elapsedH = Math.max(0, now - t.lastUpdatedAt) / HOUR_MS;
  const rates = totalRates(bases);
  const caps = totalCaps(bases);
  const stock = { ...t.stock };
  for (const r of RESOURCES) {
    stock[r] = Math.max(t.stock[r], Math.min(caps[r], t.stock[r] + rates[r] * elapsedH));
  }
  return { stock, lastUpdatedAt: Math.max(now, t.lastUpdatedAt) };
}

export function isValidLevel(level: number): boolean {
  return Number.isInteger(level) && level >= 1 && level <= MAX_LEVEL;
}
