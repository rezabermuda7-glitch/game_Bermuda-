export type Resource = 'food' | 'ammo' | 'troops';
export type BaseKind = 'fortress' | 'farm' | 'armory' | 'barracks';
export type UnitType = 'infantry' | 'cavalry' | 'catapult';

export type Stock = Record<Resource, number>;

export interface BaseState {
  kind: BaseKind;
  level: number;
}

/** The country treasury. `stock` is valid as of `lastUpdatedAt`; use settleCountry for "now". */
export interface Treasury {
  stock: Stock;
  lastUpdatedAt: number;
}

export interface Point {
  x: number;
  y: number;
}
