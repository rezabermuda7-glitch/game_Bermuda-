import { BASE_COST, COST_GROWTH, MAX_LEVEL } from './config.ts';
import { settleCountry } from './production.ts';
import type { BaseKind, BaseState, Stock, Treasury } from './types.ts';

export function upgradeCost(kind: BaseKind, level: number): Pick<Stock, 'food' | 'ammo'> {
  const f = Math.pow(COST_GROWTH, level - 1);
  return {
    food: Math.ceil(BASE_COST[kind].food * f),
    ammo: Math.ceil(BASE_COST[kind].ammo * f),
  };
}

export type UpgradeResult =
  | { ok: true; bases: BaseState[]; treasury: Treasury; paid: Pick<Stock, 'food' | 'ammo'> }
  | { ok: false; reason: 'not_found' | 'max_level' | 'insufficient_resources' };

/**
 * Upgrade the base at `index`. The treasury is settled at the OLD rates first so that
 * no accrued production is lost or double-counted when the rate changes.
 * Pure: returns new objects and never mutates its inputs.
 */
export function tryUpgradeBase(
  treasury: Treasury,
  bases: BaseState[],
  index: number,
  now: number,
): UpgradeResult {
  const target = bases[index];
  if (!target) return { ok: false, reason: 'not_found' };
  if (target.level >= MAX_LEVEL) return { ok: false, reason: 'max_level' };
  const settled = settleCountry(treasury, bases, now);
  const cost = upgradeCost(target.kind, target.level);
  if (settled.stock.food < cost.food || settled.stock.ammo < cost.ammo) {
    return { ok: false, reason: 'insufficient_resources' };
  }
  return {
    ok: true,
    paid: cost,
    bases: bases.map((b, i) => (i === index ? { ...b, level: b.level + 1 } : b)),
    treasury: {
      lastUpdatedAt: settled.lastUpdatedAt,
      stock: {
        ...settled.stock,
        food: settled.stock.food - cost.food,
        ammo: settled.stock.ammo - cost.ammo,
      },
    },
  };
}
