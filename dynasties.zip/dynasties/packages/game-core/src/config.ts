import type { BaseKind, Resource, Stock } from './types.ts';

export const MAX_LEVEL = 20;
export const RATE_GROWTH = 1.35;
export const CAP_GROWTH = 1.5;
export const COST_GROWTH = 1.6;

/** Production per hour at level 1. Fortress produces nothing; it is for defense (phase 5). */
export const BASE_RATE_PER_HOUR: Record<BaseKind, Partial<Record<Resource, number>>> = {
  fortress: {},
  farm: { food: 60 },
  armory: { ammo: 30 },
  barracks: { troops: 12 },
};

/** Storage cap per resource at level 1. */
export const BASE_CAP: Record<BaseKind, Partial<Record<Resource, number>>> = {
  fortress: {},
  farm: { food: 600 },
  armory: { ammo: 300 },
  barracks: { troops: 120 },
};

/** Upgrade cost at level 1 -> 2 is BASE_COST * COST_GROWTH^(level-1). Paid in game resources, never money. */
export const BASE_COST: Record<BaseKind, Pick<Stock, 'food' | 'ammo'>> = {
  fortress: { food: 80, ammo: 60 },
  farm: { food: 50, ammo: 20 },
  armory: { food: 60, ammo: 30 },
  barracks: { food: 70, ammo: 40 },
};

/** Minimum income per hour every country always receives (anti-stuck). */
export const FLOOR_RATE_PER_HOUR: Stock = { food: 10, ammo: 4, troops: 1 };

/** Floor stock cap so the floor income has somewhere to go. */
export const FLOOR_CAP: Stock = { food: 200, ammo: 100, troops: 40 };

export const STARTING_STOCK: Stock = { food: 150, ammo: 60, troops: 10 };

export const BASE_KINDS: BaseKind[] = ['fortress', 'farm', 'armory', 'barracks'];
export const MAP_SIZE = 1000;
export const MIN_COUNTRY_DISTANCE = 80;
