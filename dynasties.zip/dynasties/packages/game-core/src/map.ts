import { MAP_SIZE, MIN_COUNTRY_DISTANCE } from './config.ts';
import type { Point } from './types.ts';

export function distance(a: Point, b: Point): number {
  return Math.hypot(a.x - b.x, a.y - b.y);
}

/** Deterministic PRNG so placement is reproducible in tests. */
export function mulberry32(seed: number): () => number {
  let t = seed >>> 0;
  return () => {
    t += 0x6d2b79f5;
    let r = Math.imul(t ^ (t >>> 15), 1 | t);
    r ^= r + Math.imul(r ^ (r >>> 7), 61 | r);
    return ((r ^ (r >>> 14)) >>> 0) / 4294967296;
  };
}

/**
 * Pick a free spot at least MIN_COUNTRY_DISTANCE away from all existing countries.
 * Returns null if the map is too crowded after `attempts` tries.
 */
export function placeCountry(
  existing: Point[],
  rand: () => number = Math.random,
  attempts = 500,
): Point | null {
  const margin = 40;
  for (let i = 0; i < attempts; i++) {
    const p = {
      x: Math.round(margin + rand() * (MAP_SIZE - 2 * margin)),
      y: Math.round(margin + rand() * (MAP_SIZE - 2 * margin)),
    };
    if (existing.every((e) => distance(e, p) >= MIN_COUNTRY_DISTANCE)) return p;
  }
  return null;
}
