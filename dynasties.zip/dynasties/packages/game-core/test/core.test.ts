import { describe, it } from 'node:test';
import assert from 'node:assert/strict';
import {
  capFor, distance, mulberry32, placeCountry, ratePerHour, settleCountry,
  totalCaps, totalRates, tryUpgradeBase, upgradeCost,
  FLOOR_RATE_PER_HOUR, MAX_LEVEL, MIN_COUNTRY_DISTANCE,
} from '../src/index.ts';
import type { BaseState, Treasury } from '../src/index.ts';

const HOUR = 3_600_000;
const zero = { food: 0, ammo: 0, troops: 0 };
const treasury = (over: Partial<Treasury> = {}): Treasury => ({ stock: { ...zero }, lastUpdatedAt: 0, ...over });
const farm: BaseState = { kind: 'farm', level: 1 };
const close = (a: number, b: number) => assert.ok(Math.abs(a - b) < 1e-6, `${a} !~ ${b}`);

describe('production', () => {
  it('higher level means higher rate and cap', () => {
    assert.ok(ratePerHour('farm', 3, 'food') > ratePerHour('farm', 2, 'food'));
    assert.ok(capFor('farm', 3, 'food') > capFor('farm', 2, 'food'));
  });
  it('fortress produces nothing', () => {
    assert.equal(ratePerHour('fortress', 5, 'food'), 0);
    assert.equal(capFor('fortress', 5, 'food'), 0);
  });
  it('rates and caps include the floor', () => {
    assert.deepEqual(totalRates([]), FLOOR_RATE_PER_HOUR);
    assert.ok(totalCaps([farm]).food > totalCaps([]).food);
  });
  it('a country with NO bases still earns the floor income', () => {
    close(settleCountry(treasury(), [], HOUR).stock.food, FLOOR_RATE_PER_HOUR.food);
  });
  it('produces linearly over time', () => {
    const one = settleCountry(treasury(), [farm], HOUR).stock.food;
    const two = settleCountry(treasury(), [farm], 2 * HOUR).stock.food;
    close(one, 60 + FLOOR_RATE_PER_HOUR.food);
    close(two, 2 * one);
  });
  it('clamps to total capacity', () => {
    const s = settleCountry(treasury(), [farm], 10_000 * HOUR);
    assert.equal(s.stock.food, totalCaps([farm]).food);
  });
  it('never reduces stock above the cap', () => {
    const t = treasury({ stock: { ...zero, food: 99_999 } });
    assert.equal(settleCountry(t, [farm], 10 * HOUR).stock.food, 99_999);
  });
  it('ignores time going backwards', () => {
    const t = treasury({ lastUpdatedAt: 10 * HOUR });
    const s = settleCountry(t, [farm], 0);
    assert.equal(s.lastUpdatedAt, 10 * HOUR);
    assert.equal(s.stock.food, 0);
  });
  it('settling twice equals settling once (no double counting)', () => {
    const a = settleCountry(settleCountry(treasury(), [farm], HOUR), [farm], 2 * HOUR);
    const b = settleCountry(treasury(), [farm], 2 * HOUR);
    close(a.stock.food, b.stock.food);
  });
});

describe('upgrade', () => {
  // food 300 is below the 800 cap (floor 200 + farm 600), so production is visible
  const rich = treasury({ stock: { food: 300, ammo: 300, troops: 0 } });

  it('costs grow with level', () => {
    assert.ok(upgradeCost('farm', 2).food > upgradeCost('farm', 1).food);
  });
  it('pays, bumps the level, keeps pre-upgrade production, and does not mutate inputs', () => {
    const bases = [farm];
    const r = tryUpgradeBase(rich, bases, 0, HOUR);
    assert.equal(r.ok, true);
    if (!r.ok) return;
    assert.equal(r.bases[0].level, 2);
    assert.equal(bases[0].level, 1);
    assert.equal(rich.stock.food, 300);
    const cost = upgradeCost('farm', 1);
    close(r.treasury.stock.food, 300 + 60 + FLOOR_RATE_PER_HOUR.food - cost.food);
    assert.equal(r.treasury.lastUpdatedAt, HOUR);
  });
  it('fails without resources', () => {
    const r = tryUpgradeBase(treasury(), [farm], 0, 0);
    assert.deepEqual(r, { ok: false, reason: 'insufficient_resources' });
  });
  it('fails at max level', () => {
    assert.deepEqual(tryUpgradeBase(rich, [{ kind: 'farm', level: MAX_LEVEL }], 0, 0), {
      ok: false, reason: 'max_level',
    });
  });
  it('fails for an unknown base', () => {
    assert.deepEqual(tryUpgradeBase(rich, [farm], 5, 0), { ok: false, reason: 'not_found' });
  });
});

describe('map', () => {
  it('computes euclidean distance', () => {
    assert.equal(distance({ x: 0, y: 0 }, { x: 3, y: 4 }), 5);
  });
  it('places countries far apart', () => {
    const rand = mulberry32(42);
    const pts: { x: number; y: number }[] = [];
    for (let i = 0; i < 30; i++) {
      const p = placeCountry(pts, rand);
      assert.ok(p);
      pts.push(p!);
    }
    for (let i = 0; i < pts.length; i++)
      for (let j = i + 1; j < pts.length; j++)
        assert.ok(distance(pts[i], pts[j]) >= MIN_COUNTRY_DISTANCE);
  });
  it('returns null when the map is full', () => {
    const all = Array.from({ length: 50 }, (_, i) =>
      Array.from({ length: 50 }, (_, j) => ({ x: i * 20, y: j * 20 })),
    ).flat();
    assert.equal(placeCountry(all, mulberry32(1), 50), null);
  });
});
