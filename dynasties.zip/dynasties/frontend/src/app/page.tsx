'use client';
import { useCallback, useEffect, useState } from 'react';
import AuthForm from '@/components/AuthForm';
import CreateCountry from '@/components/CreateCountry';
import Dashboard from '@/components/Dashboard';
import WorldMap from '@/components/WorldMap';
import { useGame } from '@/hooks/useGame';

const TOKEN_KEY = 'dyn_token';

export default function Home() {
  // MVP: the JWT lives in localStorage. Moving it to an httpOnly cookie is on the phase-2 hardening list.
  const [token, setToken] = useState<string | null>(null);
  const [ready, setReady] = useState(false);

  useEffect(() => {
    setToken(localStorage.getItem(TOKEN_KEY));
    setReady(true);
  }, []);

  const saveToken = useCallback((t: string | null) => {
    if (t) localStorage.setItem(TOKEN_KEY, t);
    else localStorage.removeItem(TOKEN_KEY);
    setToken(t);
  }, []);

  const logout = useCallback(() => saveToken(null), [saveToken]);
  const { view, map, status, createCountry, upgrade } = useGame(token, logout);

  if (!ready) return null;
  if (!token) return <AuthForm onToken={saveToken} />;
  if (status === 'loading') return <p className="mt-20 text-center">در حال بارگذاری…</p>;
  if (status === 'no_country') return <CreateCountry onCreate={createCountry} />;

  return (
    <main className="mx-auto grid max-w-6xl gap-4 p-4 md:grid-cols-2">
      <div>
        {view && <Dashboard view={view} onUpgrade={upgrade} />}
        <button onClick={logout} className="mt-4 text-sm text-stone-400 underline">
          خروج
        </button>
      </div>
      <div>{map && <WorldMap map={map} myId={view?.country.id} />}</div>
    </main>
  );
}
