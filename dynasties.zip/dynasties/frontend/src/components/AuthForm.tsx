'use client';
import { useState } from 'react';
import type { FormEvent } from 'react';
import { ApiError, api } from '@/lib/api';
import { errorText } from '@/lib/messages';

export default function AuthForm({ onToken }: { onToken: (token: string) => void }) {
  const [mode, setMode] = useState<'login' | 'register'>('login');
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const [error, setError] = useState<string | null>(null);
  const [busy, setBusy] = useState(false);

  async function submit(e: FormEvent) {
    e.preventDefault();
    setBusy(true);
    setError(null);
    try {
      const { token } = await api<{ token: string }>(`/api/auth/${mode}`, {
        method: 'POST',
        body: { email, password },
      });
      onToken(token);
    } catch (err) {
      setError(errorText(err instanceof ApiError ? err.code : 'unknown'));
    } finally {
      setBusy(false);
    }
  }

  return (
    <form onSubmit={submit} className="mx-auto mt-20 w-full max-w-sm space-y-4 rounded-xl bg-stone-800 p-6 shadow-lg">
      <h1 className="text-center text-2xl font-bold text-amber-400">سلسله‌ها: جنگ مرزها</h1>
      <input
        type="email"
        required
        value={email}
        onChange={(e) => setEmail(e.target.value)}
        placeholder="ایمیل"
        dir="ltr"
        className="w-full rounded bg-stone-700 px-3 py-2 outline-none focus:ring-2 focus:ring-amber-500"
      />
      <input
        type="password"
        required
        minLength={8}
        value={password}
        onChange={(e) => setPassword(e.target.value)}
        placeholder="رمز عبور (حداقل ۸ نویسه)"
        dir="ltr"
        className="w-full rounded bg-stone-700 px-3 py-2 outline-none focus:ring-2 focus:ring-amber-500"
      />
      {error && <p className="text-sm text-red-400">{error}</p>}
      <button
        disabled={busy}
        className="w-full rounded bg-amber-600 py-2 font-semibold text-stone-900 hover:bg-amber-500 disabled:opacity-50"
      >
        {mode === 'login' ? 'ورود' : 'ثبت‌نام'}
      </button>
      <button
        type="button"
        onClick={() => setMode(mode === 'login' ? 'register' : 'login')}
        className="w-full text-sm text-amber-300 underline"
      >
        {mode === 'login' ? 'حساب ندارید؟ ثبت‌نام' : 'حساب دارید؟ ورود'}
      </button>
    </form>
  );
}
