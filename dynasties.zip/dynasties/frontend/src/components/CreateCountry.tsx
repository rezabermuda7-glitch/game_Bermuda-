'use client';
import { useState } from 'react';
import type { FormEvent } from 'react';
import { ApiError } from '@/lib/api';
import { errorText } from '@/lib/messages';
import type { CreateCountryInput } from '@/hooks/useGame';

const FLAGS = ['🦁', '🐅', '🦅', '🐎', '🐉', '⚔️', '🏰', '☀️', '🌙', '⭐'];

export default function CreateCountry({ onCreate }: { onCreate: (i: CreateCountryInput) => Promise<void> }) {
  const [name, setName] = useState('');
  const [dynasty, setDynasty] = useState('');
  const [color, setColor] = useState('#c0392b');
  const [flag, setFlag] = useState(FLAGS[0]);
  const [error, setError] = useState<string | null>(null);
  const [busy, setBusy] = useState(false);

  async function submit(e: FormEvent) {
    e.preventDefault();
    setBusy(true);
    setError(null);
    try {
      await onCreate({ name, dynasty, color, flag });
    } catch (err) {
      setError(errorText(err instanceof ApiError ? err.code : 'unknown'));
    } finally {
      setBusy(false);
    }
  }

  return (
    <form onSubmit={submit} className="mx-auto mt-16 w-full max-w-md space-y-4 rounded-xl bg-stone-800 p-6 shadow-lg">
      <h2 className="text-xl font-bold text-amber-400">کشور خود را بسازید</h2>
      <input
        required
        value={name}
        onChange={(e) => setName(e.target.value)}
        placeholder="نام کشور"
        maxLength={24}
        className="w-full rounded bg-stone-700 px-3 py-2 outline-none focus:ring-2 focus:ring-amber-500"
      />
      <input
        required
        value={dynasty}
        onChange={(e) => setDynasty(e.target.value)}
        placeholder="نام سلسله"
        maxLength={32}
        className="w-full rounded bg-stone-700 px-3 py-2 outline-none focus:ring-2 focus:ring-amber-500"
      />
      <div className="flex items-center gap-3">
        <label className="text-sm">رنگ روی نقشه</label>
        <input type="color" value={color} onChange={(e) => setColor(e.target.value)} className="h-9 w-14 rounded" />
      </div>
      <div>
        <p className="mb-2 text-sm">پرچم</p>
        <div className="flex flex-wrap gap-2">
          {FLAGS.map((f) => (
            <button
              type="button"
              key={f}
              onClick={() => setFlag(f)}
              className={`rounded px-3 py-1 text-2xl ${flag === f ? 'bg-amber-600' : 'bg-stone-700'}`}
            >
              {f}
            </button>
          ))}
        </div>
      </div>
      {error && <p className="text-sm text-red-400">{error}</p>}
      <button
        disabled={busy}
        className="w-full rounded bg-amber-600 py-2 font-semibold text-stone-900 hover:bg-amber-500 disabled:opacity-50"
      >
        تأسیس کشور
      </button>
    </form>
  );
}
