'use client';
import type { MapSnapshot } from '@/lib/api';

export default function WorldMap({ map, myId }: { map: MapSnapshot; myId?: string }) {
  const s = map.size;
  const grid = Array.from({ length: 9 }, (_, i) => ((i + 1) * s) / 10);
  return (
    <svg
      viewBox={`0 0 ${s} ${s}`}
      className="aspect-square w-full rounded-xl bg-stone-800"
      role="img"
      aria-label="نقشه‌ی جهان"
    >
      {grid.map((g) => (
        <g key={g} stroke="#44403c" strokeWidth="1">
          <line x1={g} y1={0} x2={g} y2={s} />
          <line x1={0} y1={g} x2={s} y2={g} />
        </g>
      ))}
      {map.countries.map((c) => (
        <g key={c.id} transform={`translate(${c.x} ${c.y})`}>
          <circle r={c.id === myId ? 26 : 20} fill={c.color} stroke={c.id === myId ? '#fde68a' : '#0c0a09'} strokeWidth={c.id === myId ? 5 : 2} />
          <text textAnchor="middle" dominantBaseline="central" fontSize="22">
            {c.flag}
          </text>
          <text y={40} textAnchor="middle" fontSize="20" fill="#fef3c7">
            {c.name}
          </text>
        </g>
      ))}
    </svg>
  );
}
