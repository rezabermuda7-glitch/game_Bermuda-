'use client';
import { useState } from 'react';
import { ApiError } from '@/lib/api';
import type { CountryView, Resource } from '@/lib/api';
import { BASE_NAMES, RESOURCE_NAMES, errorText } from '@/lib/messages';
import { useLiveStock } from '@/hooks/useLiveStock';

const RESOURCES: Resource[] = ['food', 'ammo', 'troops'];
const fmt = (n: number) => Math.floor(n).toLocaleString('fa-IR');

export default function Dashboard({
  view,
  onUpgrade,
}: {
  view: CountryView;
  onUpgrade: (index: number) => Promise<void>;
}) {
  const live = useLiveStock(view);
  const [error, setError] = useState<string | null>(null);
  const [pending, setPending] = useState<number | null>(null);

  async function upgrade(index: number) {
    setPending(index);
    setError(null);
    try {
      await onUpgrade(index);
    } catch (err) {
      setError(errorText(err instanceof ApiError ? err.code : 'unknown'));
    } finally {
      setPending(null);
    }
  }

  const { country } = view;
  return (
    <div className="space-y-4">
      <header className="flex items-center gap-3 rounded-xl bg-stone-800 p-4">
        <span className="text-3xl">{country.flag}</span>
        <div>
          <h2 className="text-lg font-bold" style={{ color: country.color }}>
            {country.name}
          </h2>
          <p className="text-sm text-stone-400">سلسله‌ی {country.dynasty}</p>
        </div>
      </header>

      <section className="grid grid-cols-3 gap-3">
        {RESOURCES.map((r) => (
          <div key={r} className="rounded-xl bg-stone-800 p-3 text-center">
            <p className="text-sm text-stone-400">{RESOURCE_NAMES[r]}</p>
            <p className="text-2xl font-bold text-amber-300">{live ? fmt(live[r]) : '…'}</p>
            <p className="text-xs text-stone-500">
              سقف {fmt(view.caps[r])} · +{fmt(view.ratesPerHour[r])}/ساعت
            </p>
          </div>
        ))}
      </section>

      {error && <p className="text-sm text-red-400">{error}</p>}

      <section className="space-y-2">
        {view.bases.map((b) => {
          const cost = b.upgradeCost;
          const affordable = !!cost && !!live && live.food >= cost.food && live.ammo >= cost.ammo;
          return (
            <div key={b.index} className="flex items-center justify-between rounded-xl bg-stone-800 p-3">
              <div>
                <p className="font-semibold">
                  {BASE_NAMES[b.kind]} <span className="text-amber-400">سطح {b.level.toLocaleString('fa-IR')}</span>
                </p>
                <p className="text-xs text-stone-400">
                  {cost
                    ? `هزینه‌ی ارتقا: ${fmt(cost.food)} غذا، ${fmt(cost.ammo)} مهمات`
                    : 'بالاترین سطح'}
                </p>
              </div>
              <button
                disabled={!cost || !affordable || pending !== null}
                onClick={() => upgrade(b.index)}
                className="rounded bg-amber-600 px-4 py-1.5 text-sm font-semibold text-stone-900 hover:bg-amber-500 disabled:opacity-40"
              >
                ارتقا
              </button>
            </div>
          );
        })}
      </section>
    </div>
  );
}
