const MESSAGES: Record<string, string> = {
  network: 'ارتباط با سرور برقرار نشد.',
  invalid_email: 'ایمیل معتبر نیست.',
  invalid_password: 'رمز عبور باید بین ۸ تا ۱۲۸ نویسه باشد.',
  email_taken: 'این ایمیل قبلاً ثبت شده است.',
  invalid_credentials: 'ایمیل یا رمز عبور اشتباه است.',
  rate_limited: 'درخواست‌های زیاد؛ کمی بعد دوباره تلاش کنید.',
  invalid_name: 'نام کشور باید ۳ تا ۲۴ نویسه (حرف، عدد، فاصله) باشد.',
  invalid_dynasty: 'نام سلسله باید ۲ تا ۳۲ نویسه باشد.',
  invalid_color: 'رنگ نامعتبر است.',
  invalid_flag: 'پرچم نامعتبر است.',
  country_exists: 'شما قبلاً یک کشور ساخته‌اید.',
  name_taken: 'این نام کشور قبلاً گرفته شده است.',
  map_full: 'جایی روی نقشه باقی نمانده است.',
  insufficient_resources: 'منابع کافی برای این ارتقا ندارید.',
  max_level: 'این پایگاه به بالاترین سطح رسیده است.',
  invalid_token: 'نشست شما منقضی شده است. دوباره وارد شوید.',
  missing_token: 'ابتدا وارد شوید.',
};

export function errorText(code: string): string {
  return MESSAGES[code] ?? 'خطای ناشناخته رخ داد.';
}

export const BASE_NAMES: Record<string, string> = {
  fortress: 'قلعه',
  farm: 'مزرعه',
  armory: 'زرادخانه',
  barracks: 'پادگان',
};

export const RESOURCE_NAMES: Record<string, string> = {
  food: 'غذا',
  ammo: 'مهمات',
  troops: 'نیرو',
};
