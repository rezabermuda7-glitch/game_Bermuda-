export const API_URL = process.env.NEXT_PUBLIC_API_URL ?? 'http://localhost:4000';

export type Resource = 'food' | 'ammo' | 'troops';
export type Stock = Record<Resource, number>;

export interface PublicCountry {
  id: string;
  name: string;
  dynasty: string;
  color: string;
  flag: string;
  x: number;
  y: number;
}

export interface BaseView {
  index: number;
  kind: 'fortress' | 'farm' | 'armory' | 'barracks';
  level: number;
  maxLevel: number;
  upgradeCost: { food: number; ammo: number } | null;
}

export interface CountryView {
  country: PublicCountry;
  serverTime: number;
  stock: Stock;
  ratesPerHour: Stock;
  caps: Stock;
  bases: BaseView[];
}

export interface MapSnapshot {
  size: number;
  countries: PublicCountry[];
}

export class ApiError extends Error {
  status: number;
  code: string;
  constructor(status: number, code: string) {
    super(code);
    this.status = status;
    this.code = code;
  }
}

export async function api<T>(
  path: string,
  opts: { method?: string; body?: unknown; token?: string | null } = {},
): Promise<T> {
  let res: Response;
  try {
    res = await fetch(API_URL + path, {
      method: opts.method ?? 'GET',
      headers: {
        ...(opts.body !== undefined ? { 'content-type': 'application/json' } : {}),
        ...(opts.token ? { authorization: `Bearer ${opts.token}` } : {}),
      },
      body: opts.body !== undefined ? JSON.stringify(opts.body) : undefined,
    });
  } catch {
    throw new ApiError(0, 'network');
  }
  const data = await res.json().catch(() => null);
  if (!res.ok) throw new ApiError(res.status, data?.error ?? 'unknown');
  return data as T;
}
