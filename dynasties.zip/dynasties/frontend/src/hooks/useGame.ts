'use client';
import { useCallback, useEffect, useState } from 'react';
import { io } from 'socket.io-client';
import { API_URL, ApiError, api } from '@/lib/api';
import type { CountryView, MapSnapshot, PublicCountry } from '@/lib/api';

export type GameStatus = 'loading' | 'no_country' | 'ready';

export interface CreateCountryInput {
  name: string;
  dynasty: string;
  color: string;
  flag: string;
}

export function useGame(token: string | null, onAuthError: () => void) {
  const [view, setView] = useState<CountryView | null>(null);
  const [map, setMap] = useState<MapSnapshot | null>(null);
  const [status, setStatus] = useState<GameStatus>('loading');

  useEffect(() => {
    if (!token) return;
    let cancelled = false;
    setStatus('loading');

    (async () => {
      try {
        const m = await api<MapSnapshot>('/api/map', { token });
        if (!cancelled) setMap(m);
        try {
          const v = await api<CountryView>('/api/country', { token });
          if (!cancelled) {
            setView(v);
            setStatus('ready');
          }
        } catch (e) {
          if (e instanceof ApiError && e.code === 'no_country') {
            if (!cancelled) setStatus('no_country');
          } else throw e;
        }
      } catch (e) {
        if (e instanceof ApiError && e.status === 401) onAuthError();
      }
    })();

    const socket = io(API_URL, { auth: { token } });
    socket.on('state:snapshot', (v: CountryView) => {
      setView(v);
      setStatus('ready');
    });
    socket.on('map:country_added', (c: PublicCountry) =>
      setMap((m) => (m && !m.countries.some((x) => x.id === c.id) ? { ...m, countries: [...m.countries, c] } : m)),
    );
    socket.on('connect_error', (err) => {
      if (err.message === 'unauthorized') onAuthError();
    });

    return () => {
      cancelled = true;
      socket.disconnect();
    };
    // onAuthError is intentionally excluded: it is stable for the lifetime of a token
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [token]);

  const createCountry = useCallback(
    async (input: CreateCountryInput) => {
      const v = await api<CountryView>('/api/country', { method: 'POST', body: input, token });
      setView(v);
      setStatus('ready');
      setMap(await api<MapSnapshot>('/api/map', { token }));
    },
    [token],
  );

  const upgrade = useCallback(
    async (index: number) => {
      setView(await api<CountryView>(`/api/country/bases/${index}/upgrade`, { method: 'POST', token }));
    },
    [token],
  );

  return { view, map, status, createCountry, upgrade };
}
