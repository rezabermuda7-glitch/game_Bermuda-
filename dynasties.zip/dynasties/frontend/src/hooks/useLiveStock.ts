'use client';
import { useEffect, useRef, useState } from 'react';
import type { CountryView, Resource, Stock } from '@/lib/api';

const RESOURCES: Resource[] = ['food', 'ammo', 'troops'];

/**
 * Extrapolates the server snapshot locally once per second using the same formula as the server
 * (linear production clamped to the cap), so numbers move smoothly without polling.
 * The server stays the source of truth: every new snapshot replaces the local estimate.
 */
export function useLiveStock(view: CountryView | null): Stock | null {
  const [now, setNow] = useState(() => Date.now());
  const receivedAt = useRef(Date.now());

  useEffect(() => {
    receivedAt.current = Date.now();
    setNow(Date.now());
  }, [view]);

  useEffect(() => {
    const t = setInterval(() => setNow(Date.now()), 1000);
    return () => clearInterval(t);
  }, []);

  if (!view) return null;
  const hours = Math.max(0, now - receivedAt.current) / 3_600_000;
  const out = { food: 0, ammo: 0, troops: 0 } as Stock;
  for (const r of RESOURCES) {
    out[r] = Math.max(view.stock[r], Math.min(view.caps[r], view.stock[r] + view.ratesPerHour[r] * hours));
  }
  return out;
}
