# معماری «سلسله‌ها: جنگ مرزها» (Dynasties: Border Wars)

## اصول طراحی

1. **سرور مرجع است (server-authoritative).** کلاینت فقط دستور می‌فرستد و وضعیت را نمایش می‌دهد.
2. **تولید منابع لحظه‌ای نیست، محاسبه‌ای است.** به‌جای tick برای هر پایگاه، برای هر پایگاه `lastUpdatedAt` و نرخ تولید ذخیره می‌شود و مقدار فعلی از فرمول
   `مقدار = min(ظرفیت, ذخیره + نرخ × (اکنون − lastUpdatedAt))` به‌دست می‌آید.
   مزیت: پلیر آفلاین بدون هزینه به تولید ادامه می‌دهد و هیچ لگی وجود ندارد.
3. **هسته‌ی بازی = توابع خالص.** تمام قوانین (تولید، ارتقا، هزینه، فاصله، زمان کاروان، نسبت نیرو برای شکستن مرز) در `packages/game-core` بدون وابستگی به دیتابیس و شبکه نوشته می‌شوند تا کاملاً قابل تست باشند.
4. **Repository pattern.** سرویس‌ها به یک interface وابسته‌اند؛ دو پیاده‌سازی دارد: `InMemory` (برای تست) و `Postgres` (برای اجرا).
5. **رویدادهای زمان‌دار** (کاروان، حمله، ساخت) در جدول `events` با `executeAt` ذخیره می‌شوند و یک scheduler سبک آن‌ها را اجرا می‌کند. با ری‌استارت سرور چیزی گم نمی‌شود.

## ساختار پوشه‌ها

```
dynasties/
├─ docs/                      ARCHITECTURE.md, ROADMAP.md
├─ docker-compose.yml         Postgres + Redis
├─ packages/
│  └─ game-core/              قوانین خالص بازی + تست
│     ├─ src/{config,production,upgrade,map,combat,convoy,embargo,border}.ts
│     └─ test/
├─ backend/
│  ├─ src/
│  │  ├─ config/              env
│  │  ├─ db/                  schema.sql، اتصال pg/redis
│  │  ├─ modules/
│  │  │  ├─ auth/             ثبت‌نام، ورود، JWT
│  │  │  ├─ country/          ساخت کشور، سلسله، پرچم/رنگ
│  │  │  ├─ base/             پایگاه، ارتقا، تولید
│  │  │  ├─ map/              جای‌گذاری کشورها، فاصله
│  │  │  ├─ market/           (فاز ۳) بازار و معامله
│  │  │  ├─ convoy/           (فاز ۳) کاروان
│  │  │  ├─ embargo/          (فاز ۴) تحریم
│  │  │  ├─ border/           (فاز ۴) بستن مرز
│  │  │  └─ war/              (فاز ۵) حمله و غارت
│  │  ├─ realtime/            Socket.io، اتاق‌ها، احراز هویت سوکت
│  │  └─ scheduler/           اجرای رویدادهای زمان‌دار
│  └─ test/
└─ frontend/                  Next.js + React + Tailwind
   └─ src/{app,components,lib,hooks}
```

## مدل داده (خلاصه)

| جدول | فیلدهای کلیدی |
|---|---|
| users | id, email, password_hash, created_at, last_seen_at, vacation_until |
| countries | id, user_id (یکتا), name, dynasty, color, flag, x, y |
| bases | id, country_id, kind (`fortress`/`farm`/`armory`/`barracks`), level, stock_*, last_updated_at |
| units | country_id, type (`infantry`/`cavalry`/`catapult`), count |
| events (فاز ۳+) | id, type, payload, execute_at, status |
| listings / trades / convoys (فاز ۳) | آگهی، معامله، کاروان |
| embargoes / border_state / trade_log (فاز ۴) | تحریم، وضعیت مرز، گزارش تجارت |

منابع: `food`, `ammo`, `troops` (نیرو). **هیچ منبعی با پول سیستمی خرید/فروش نمی‌شود.** «پول» فقط یک منبع بین‌پلیری است (از فاز ۳).

## قوانین هسته (MVP)

- **نرخ تولید** پایگاه نوع `t` در سطح `L`: `base_rate[t] × growth^(L−1)`
- **ظرفیت انبار:** `base_cap[t] × cap_growth^(L−1)`
- **هزینه‌ی ارتقا:** از خود منابع تولیدشده (غذا و مهمات)، نه پول: `cost = base_cost × cost_growth^L`
- **درآمد پایه (anti-stuck):** هر کشور حداقل یک نرخ کف از هر منبع دارد، حتی اگر پایگاه‌هایش ضعیف یا مسدود باشند.
- **فاصله:** فاصله‌ی اقلیدسی روی نقشه؛ زمان کاروان = `distance / speed`.
- **شکستن مرز (فاز ۵):** `attackerPower ≥ 1.5 × defenderPower`

## رویدادهای Socket.io

کلاینت → سرور: `country:create` (از طریق REST)، `base:upgrade`، `map:subscribe`
سرور → کلاینت: `state:snapshot`، `base:updated`، `map:country_added`، `error`

احراز هویت سوکت با JWT در `handshake.auth.token`. هر کشور در اتاق `country:{id}` است و نقشه در اتاق `map`.

## ضد تقلب (از اول در طراحی)

- محدودیت ثبت‌نام: هر کاربر یک کشور (قید یکتا در DB)، rate-limit روی ثبت‌نام و ورود.
- (فاز ۴) لاگ تجارت + شناسایی انتقال یک‌طرفه‌ی مشکوک بین حساب‌ها (هم‌IP، نسبت نامتعارف، شبکه‌ی بسته).
- تحریم محدود: هر تحریم کامل نیاز به اتحاد دارد و تحریم‌شده همیشه درآمد پایه را نگه می‌دارد.
- دفاع خودکار آفلاین: ۶۰٪ قدرت آنلاین؛ حالت Vacation حداکثر چند روز و با cooldown.
