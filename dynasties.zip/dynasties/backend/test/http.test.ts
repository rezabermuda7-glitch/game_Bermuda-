import { after, before, describe, it } from 'node:test';
import assert from 'node:assert/strict';
import type { AddressInfo } from 'node:net';
import type { Server } from 'node:http';
import { createBus } from '../src/bus.ts';
import { createHttpServer } from '../src/http/server.ts';
import { MemoryRepository } from '../src/repo/memory.ts';
import { AuthService } from '../src/modules/auth/auth.service.ts';
import { CountryService } from '../src/modules/country/country.service.ts';
import { GameService } from '../src/modules/base/game.service.ts';
import { MapService } from '../src/modules/map/map.service.ts';

const SECRET = 'test-secret-0123456789';
const country = { name: 'Persia', dynasty: 'Achaemenid', color: '#c0392b', flag: '🦁' };

let server: Server;
let base: string;
let now = 1_000_000;

async function api(method: string, path: string, body?: unknown, token?: string, raw?: string) {
  const res = await fetch(base + path, {
    method,
    headers: {
      ...(body !== undefined || raw !== undefined ? { 'content-type': 'application/json' } : {}),
      ...(token ? { authorization: `Bearer ${token}` } : {}),
    },
    body: raw ?? (body === undefined ? undefined : JSON.stringify(body)),
  });
  return { status: res.status, json: (await res.json().catch(() => null)) as any, headers: res.headers };
}

async function newPlayer(email: string) {
  const r = await api('POST', '/api/auth/register', { email, password: 'password123' });
  assert.equal(r.status, 201);
  return r.json.token as string;
}

before(async () => {
  const clock = () => now;
  const repo = new MemoryRepository();
  const bus = createBus();
  server = createHttpServer({
    auth: new AuthService(repo, SECRET, 3600, clock),
    countries: new CountryService(repo, bus, clock),
    game: new GameService(repo, bus, clock),
    map: new MapService(repo),
    jwtSecret: SECRET,
    corsOrigin: 'http://localhost:3000',
    clock,
    authRateLimit: { max: 40, windowMs: 60_000 },
  });
  await new Promise<void>((r) => server.listen(0, '127.0.0.1', r));
  base = `http://127.0.0.1:${(server.address() as AddressInfo).port}`;
});

after(() => new Promise<void>((r) => server.close(() => r())));

describe('http api', () => {
  it('health check', async () => {
    assert.deepEqual((await api('GET', '/health')).json, { ok: true });
  });

  it('unknown route -> 404, bad json -> 400, huge body -> 413', async () => {
    assert.equal((await api('GET', '/nope')).status, 404);
    const bad = await api('POST', '/api/auth/login', undefined, undefined, '{not json');
    assert.deepEqual([bad.status, bad.json.error], [400, 'invalid_json']);
    const huge = await api('POST', '/api/auth/login', undefined, undefined, JSON.stringify({ x: 'a'.repeat(20_000) }));
    assert.deepEqual([huge.status, huge.json.error], [413, 'body_too_large']);
  });

  it('sets CORS headers and answers preflight', async () => {
    const r = await fetch(base + '/api/map', { method: 'OPTIONS' });
    assert.equal(r.status, 204);
    assert.equal(r.headers.get('access-control-allow-origin'), 'http://localhost:3000');
  });

  it('protected routes require a valid token', async () => {
    for (const [m, p] of [['GET', '/api/country'], ['GET', '/api/map'], ['POST', '/api/country/bases/0/upgrade']]) {
      const r = await api(m, p);
      assert.deepEqual([r.status, r.json.error], [401, 'missing_token']);
    }
    const r = await api('GET', '/api/country', undefined, 'a.b.c');
    assert.deepEqual([r.status, r.json.error], [401, 'invalid_token']);
  });

  it('register / login flow and error codes', async () => {
    await newPlayer('flow@example.com');
    const dup = await api('POST', '/api/auth/register', { email: 'flow@example.com', password: 'password123' });
    assert.deepEqual([dup.status, dup.json.error], [409, 'email_taken']);
    const ok = await api('POST', '/api/auth/login', { email: 'flow@example.com', password: 'password123' });
    assert.equal(ok.status, 200);
    assert.ok(ok.json.token);
    const wrong = await api('POST', '/api/auth/login', { email: 'flow@example.com', password: 'wrong-pass-1' });
    assert.deepEqual([wrong.status, wrong.json.error], [401, 'invalid_credentials']);
    const weak = await api('POST', '/api/auth/register', { email: 'x@example.com', password: '1' });
    assert.deepEqual([weak.status, weak.json.error], [400, 'invalid_password']);
  });

  it('full MVP journey: create country, see state, upgrade, see map', async () => {
    const token = await newPlayer('journey@example.com');

    const none = await api('GET', '/api/country', undefined, token);
    assert.deepEqual([none.status, none.json.error], [404, 'no_country']);

    const created = await api('POST', '/api/country', country, token);
    assert.equal(created.status, 201);
    assert.equal(created.json.country.name, 'Persia');
    assert.equal(created.json.bases.length, 4);

    const again = await api('POST', '/api/country', { ...country, name: 'Second' }, token);
    assert.deepEqual([again.status, again.json.error], [409, 'country_exists']);

    const up = await api('POST', '/api/country/bases/1/upgrade', undefined, token);
    assert.equal(up.status, 200);
    assert.equal(up.json.bases[1].level, 2);

    const broke = await api('POST', '/api/country/bases/0/upgrade', undefined, token);
    assert.deepEqual([broke.status, broke.json.error], [409, 'insufficient_resources']);

    now += 1_800_000; // 30 min: production accrues, token (1h TTL) still valid
    const later = await api('GET', '/api/country', undefined, token);
    assert.ok(later.json.stock.food > up.json.stock.food);

    const map = await api('GET', '/api/map', undefined, token);
    assert.equal(map.status, 200);
    assert.ok(map.json.countries.some((c: any) => c.name === 'Persia'));
    assert.ok(map.json.countries.every((c: any) => !('treasury' in c) && !('userId' in c)));
  });

  it('players only ever affect their own country', async () => {
    const a = await newPlayer('a@example.com');
    const b = await newPlayer('b@example.com');
    await api('POST', '/api/country', { ...country, name: 'Alpha' }, a);
    await api('POST', '/api/country', { ...country, name: 'Beta' }, b);
    await api('POST', '/api/country/bases/1/upgrade', undefined, a);
    const sb = await api('GET', '/api/country', undefined, b);
    assert.equal(sb.json.bases[1].level, 1);
  });

  it('rate-limits auth endpoints', async () => {
    let last = 0;
    for (let i = 0; i < 60; i++) {
      last = (await api('POST', '/api/auth/login', { email: 'x@example.com', password: 'password123' })).status;
      if (last === 429) break;
    }
    assert.equal(last, 429);
  });
});
