import { describe, it } from 'node:test';
import assert from 'node:assert/strict';
import { distance, mulberry32, MIN_COUNTRY_DISTANCE, STARTING_STOCK } from '@dynasties/game-core';
import { createBus } from '../src/bus.ts';
import { AppError } from '../src/errors.ts';
import { MemoryRepository } from '../src/repo/memory.ts';
import { CountryService } from '../src/modules/country/country.service.ts';
import { GameService } from '../src/modules/base/game.service.ts';
import { MapService } from '../src/modules/map/map.service.ts';

const HOUR = 3_600_000;
const valid = { name: 'Persia', dynasty: 'Achaemenid', color: '#c0392b', flag: '🦁' };

function setup() {
  let now = 1_000_000;
  const clock = () => now;
  const repo = new MemoryRepository();
  const bus = createBus();
  const countries = new CountryService(repo, bus, clock, mulberry32(7));
  const game = new GameService(repo, bus, clock);
  const map = new MapService(repo);
  return { repo, bus, countries, game, map, advance: (ms: number) => (now += ms) };
}

const rejects = (p: Promise<unknown>, status: number, code: string) =>
  assert.rejects(p, (e: unknown) => e instanceof AppError && e.status === status && e.code === code);

describe('country creation', () => {
  it('creates a country with starting stock and four level-1 bases', async () => {
    const { countries, game } = setup();
    await countries.create('u1', valid);
    const s = await game.getState('u1');
    assert.equal(s.country.name, 'Persia');
    assert.deepEqual(s.stock, STARTING_STOCK);
    assert.deepEqual(s.bases.map((b) => b.kind), ['fortress', 'farm', 'armory', 'barracks']);
    assert.ok(s.bases.every((b) => b.level === 1));
  });

  it('validates every field', async () => {
    const { countries } = setup();
    await rejects(countries.create('u1', { ...valid, name: 'ab' }), 400, 'invalid_name');
    await rejects(countries.create('u1', { ...valid, name: '<script>' }), 400, 'invalid_name');
    await rejects(countries.create('u1', { ...valid, dynasty: '' }), 400, 'invalid_dynasty');
    await rejects(countries.create('u1', { ...valid, color: 'red' }), 400, 'invalid_color');
    await rejects(countries.create('u1', { ...valid, flag: '<b>' }), 400, 'invalid_flag');
    await rejects(countries.create('u1', null), 400, 'invalid_name');
  });

  it('accepts Persian names', async () => {
    const { countries } = setup();
    await countries.create('u1', { ...valid, name: 'ایران بزرگ', dynasty: 'هخامنشی' });
  });

  it('allows one country per user and unique names', async () => {
    const { countries } = setup();
    await countries.create('u1', valid);
    await rejects(countries.create('u1', { ...valid, name: 'Other' }), 409, 'country_exists');
    await rejects(countries.create('u2', { ...valid, name: 'PERSIA' }), 409, 'name_taken');
  });

  it('places countries at least MIN_COUNTRY_DISTANCE apart, even when created concurrently', async () => {
    const { countries, map } = setup();
    await Promise.all(
      Array.from({ length: 15 }, (_, i) => countries.create(`u${i}`, { ...valid, name: `Land ${i}` })),
    );
    const { countries: all } = await map.snapshot();
    assert.equal(all.length, 15);
    for (let i = 0; i < all.length; i++)
      for (let j = i + 1; j < all.length; j++)
        assert.ok(distance(all[i], all[j]) >= MIN_COUNTRY_DISTANCE);
  });

  it('emits country:created', async () => {
    const { countries, bus } = setup();
    const seen: unknown[] = [];
    bus.on('country:created', (e) => seen.push(e));
    await countries.create('u1', valid);
    assert.equal(seen.length, 1);
    assert.equal((seen[0] as any).userId, 'u1');
  });

  it('the map never leaks treasuries or owner ids', async () => {
    const { countries, map } = setup();
    await countries.create('u1', valid);
    const [c] = (await map.snapshot()).countries;
    assert.deepEqual(Object.keys(c).sort(), ['color', 'dynasty', 'flag', 'id', 'name', 'x', 'y']);
  });
});

describe('game state and production', () => {
  it('returns 404 for a user without a country', async () => {
    const { game } = setup();
    await rejects(game.getState('nobody'), 404, 'no_country');
  });

  it('production accrues with time, including while "offline"', async () => {
    const { countries, game, advance } = setup();
    await countries.create('u1', valid);
    const before = await game.getState('u1');
    advance(HOUR);
    const after = await game.getState('u1');
    assert.ok(after.stock.food > before.stock.food);
    assert.ok(after.stock.troops > before.stock.troops);
    assert.ok(after.stock.food <= after.caps.food);
  });

  it('reading state does not change stored state', async () => {
    const { countries, game, repo, advance } = setup();
    const c = await countries.create('u1', valid);
    advance(HOUR);
    await game.getState('u1');
    assert.deepEqual((await repo.findCountryById(c.id))!.treasury, c.treasury);
  });
});

describe('upgrades', () => {
  it('upgrades a base, spends resources and raises production', async () => {
    const { countries, game } = setup();
    await countries.create('u1', valid);
    const before = await game.getState('u1');
    const after = await game.upgrade('u1', 1); // farm
    assert.equal(after.bases[1].level, 2);
    assert.ok(after.ratesPerHour.food > before.ratesPerHour.food);
    assert.equal(after.stock.food, before.stock.food - before.bases[1].upgradeCost!.food);
  });

  it('rejects when resources are insufficient, and charges nothing', async () => {
    const { countries, game } = setup();
    await countries.create('u1', valid);
    await game.upgrade('u1', 1);
    const before = await game.getState('u1');
    await rejects(game.upgrade('u1', 0), 409, 'insufficient_resources');
    assert.deepEqual((await game.getState('u1')).stock, before.stock);
  });

  it('can afford it after waiting', async () => {
    const { countries, game, advance } = setup();
    await countries.create('u1', valid);
    await game.upgrade('u1', 1);
    await rejects(game.upgrade('u1', 0), 409, 'insufficient_resources');
    advance(2 * HOUR);
    assert.equal((await game.upgrade('u1', 0)).bases[0].level, 2);
  });

  it('validates the base index', async () => {
    const { countries, game } = setup();
    await countries.create('u1', valid);
    await rejects(game.upgrade('u1', -1), 400, 'invalid_base');
    await rejects(game.upgrade('u1', 1.5), 400, 'invalid_base');
    await rejects(game.upgrade('u1', '1'), 400, 'invalid_base');
    await rejects(game.upgrade('u1', 99), 404, 'not_found');
    await rejects(game.upgrade('ghost', 0), 404, 'no_country');
  });

  it('concurrent upgrades cannot double-spend', async () => {
    const { countries, game, repo } = setup();
    const c = await countries.create('u1', valid);
    // starting stock affords farm L1 (50f/20a) and L2 (80f/32a) but not L3 (128f/52a)
    const results = await Promise.allSettled([
      game.upgrade('u1', 1),
      game.upgrade('u1', 1),
      game.upgrade('u1', 1),
    ]);
    assert.equal(results.filter((r) => r.status === 'fulfilled').length, 2);
    const stored = (await repo.findCountryById(c.id))!;
    assert.equal(stored.bases[1].level, 3);
    assert.ok(stored.treasury.stock.food >= 0 && stored.treasury.stock.ammo >= 0);
  });

  it('emits country:updated only on success', async () => {
    const { countries, game, bus } = setup();
    await countries.create('u1', valid);
    let n = 0;
    bus.on('country:updated', () => n++);
    await game.upgrade('u1', 1);
    await rejects(game.upgrade('u1', 99), 404, 'not_found');
    assert.equal(n, 1);
  });
});
