import { describe, it } from 'node:test';
import assert from 'node:assert/strict';
import { createHmac } from 'node:crypto';
import { signJwt, verifyJwt } from '../src/modules/auth/jwt.ts';
import { hashPassword, verifyPassword } from '../src/modules/auth/password.ts';
import { AuthService } from '../src/modules/auth/auth.service.ts';
import { MemoryRepository } from '../src/repo/memory.ts';
import { AppError } from '../src/errors.ts';

const SECRET = 'test-secret-0123456789';

const rejects = async (p: Promise<unknown>, status: number, code: string) =>
  assert.rejects(p, (e: unknown) => e instanceof AppError && e.status === status && e.code === code);

describe('jwt', () => {
  it('round-trips the subject', () => {
    assert.equal(verifyJwt(signJwt('u1', SECRET, 60), SECRET).sub, 'u1');
  });
  it('rejects a wrong secret', () => {
    assert.throws(() => verifyJwt(signJwt('u1', SECRET, 60), 'other-secret-0123456789'), AppError);
  });
  it('rejects expired tokens', () => {
    const t = signJwt('u1', SECRET, 60, 0);
    assert.doesNotThrow(() => verifyJwt(t, SECRET, 59_000));
    assert.throws(() => verifyJwt(t, SECRET, 61_000), AppError);
  });
  it('rejects tampered payloads', () => {
    const [h, , s] = signJwt('u1', SECRET, 60).split('.');
    const forged = Buffer.from(JSON.stringify({ sub: 'admin', exp: 9999999999 })).toString('base64url');
    assert.throws(() => verifyJwt(`${h}.${forged}.${s}`, SECRET), AppError);
  });
  it('rejects alg:none tokens', () => {
    const h = Buffer.from(JSON.stringify({ alg: 'none', typ: 'JWT' })).toString('base64url');
    const p = Buffer.from(JSON.stringify({ sub: 'u1', exp: 9999999999 })).toString('base64url');
    assert.throws(() => verifyJwt(`${h}.${p}.`, SECRET), AppError);
  });
  it('rejects a different header even with a valid signature', () => {
    const h = Buffer.from(JSON.stringify({ alg: 'HS512', typ: 'JWT' })).toString('base64url');
    const p = Buffer.from(JSON.stringify({ sub: 'u1', exp: 9999999999 })).toString('base64url');
    const s = createHmac('sha256', SECRET).update(`${h}.${p}`).digest('base64url');
    assert.throws(() => verifyJwt(`${h}.${p}.${s}`, SECRET), AppError);
  });
  it('rejects garbage', () => {
    for (const bad of ['', 'abc', 'a.b', 'a.b.c.d', undefined, 42]) {
      assert.throws(() => verifyJwt(bad, SECRET), AppError);
    }
  });
});

describe('password', () => {
  it('verifies the right password and rejects the wrong one', async () => {
    const h = await hashPassword('correct horse');
    assert.equal(await verifyPassword('correct horse', h), true);
    assert.equal(await verifyPassword('wrong horse', h), false);
  });
  it('salts: the same password hashes differently', async () => {
    assert.notEqual(await hashPassword('same-password'), await hashPassword('same-password'));
  });
  it('rejects malformed stored hashes', async () => {
    assert.equal(await verifyPassword('x', 'garbage'), false);
  });
});

describe('AuthService', () => {
  const make = () => new AuthService(new MemoryRepository(), SECRET, 3600);

  it('registers then logs in', async () => {
    const auth = make();
    const reg = await auth.register({ email: 'A@Example.com ', password: 'password123' });
    const login = await auth.login({ email: 'a@example.com', password: 'password123' });
    assert.equal(verifyJwt(reg.token, SECRET).sub, verifyJwt(login.token, SECRET).sub);
  });
  it('rejects duplicate emails (case-insensitive)', async () => {
    const auth = make();
    await auth.register({ email: 'a@example.com', password: 'password123' });
    await rejects(auth.register({ email: 'A@EXAMPLE.com', password: 'password123' }), 409, 'email_taken');
  });
  it('validates email and password', async () => {
    const auth = make();
    await rejects(auth.register({ email: 'nope', password: 'password123' }), 400, 'invalid_email');
    await rejects(auth.register({ email: 'a@b.co', password: 'short' }), 400, 'invalid_password');
    await rejects(auth.register(null), 400, 'invalid_email');
  });
  it('gives the same error for unknown email and wrong password', async () => {
    const auth = make();
    await auth.register({ email: 'a@example.com', password: 'password123' });
    await rejects(auth.login({ email: 'a@example.com', password: 'wrong-password' }), 401, 'invalid_credentials');
    await rejects(auth.login({ email: 'x@example.com', password: 'password123' }), 401, 'invalid_credentials');
  });
});
