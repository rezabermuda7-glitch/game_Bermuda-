import { AppError } from '../errors.ts';
import type { Country, Repository, User } from './types.ts';

const clone = <T>(v: T): T => structuredClone(v);

export class MemoryRepository implements Repository {
  private users = new Map<string, User>();
  private countries = new Map<string, Country>();
  private locks = new Map<string, Promise<unknown>>();

  async createUser(user: User): Promise<void> {
    for (const u of this.users.values()) {
      if (u.email === user.email) throw new AppError(409, 'email_taken');
    }
    this.users.set(user.id, clone(user));
  }

  async findUserByEmail(email: string) {
    for (const u of this.users.values()) if (u.email === email) return clone(u);
    return undefined;
  }

  async findUserById(id: string) {
    const u = this.users.get(id);
    return u ? clone(u) : undefined;
  }

  async createCountry(country: Country): Promise<void> {
    for (const c of this.countries.values()) {
      if (c.userId === country.userId) throw new AppError(409, 'country_exists');
      if (c.name.toLowerCase() === country.name.toLowerCase()) throw new AppError(409, 'name_taken');
    }
    this.countries.set(country.id, clone(country));
  }

  async findCountryById(id: string) {
    const c = this.countries.get(id);
    return c ? clone(c) : undefined;
  }

  async findCountryByUserId(userId: string) {
    for (const c of this.countries.values()) if (c.userId === userId) return clone(c);
    return undefined;
  }

  async listCountries() {
    return [...this.countries.values()].map(clone);
  }

  /** Serialized per country through a promise chain (the in-memory analogue of SELECT ... FOR UPDATE). */
  updateCountry(id: string, fn: (current: Country) => Country): Promise<Country> {
    const prev = this.locks.get(id) ?? Promise.resolve();
    const run = prev.then(() => {
      const current = this.countries.get(id);
      if (!current) throw new AppError(404, 'country_not_found');
      const next = fn(clone(current));
      this.countries.set(id, clone(next));
      return clone(next);
    });
    // keep the chain alive even if this step fails
    this.locks.set(id, run.catch(() => undefined));
    return run;
  }
}
