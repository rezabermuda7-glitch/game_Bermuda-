import type { BaseState, Treasury } from '@dynasties/game-core';

export interface User {
  id: string;
  email: string;
  passwordHash: string;
  createdAt: number;
}

export interface Country {
  id: string;
  userId: string;
  name: string;
  dynasty: string;
  color: string;
  flag: string;
  x: number;
  y: number;
  createdAt: number;
  treasury: Treasury;
  bases: BaseState[];
}

/**
 * Persistence boundary. Two implementations: in-memory (tests, local dev) and Postgres.
 * `updateCountry` MUST be atomic per country: concurrent calls are serialized so that
 * read-modify-write (e.g. upgrades) cannot interleave and double-spend resources.
 * Duplicate keys throw AppError(409) with code email_taken | country_exists | name_taken.
 */
export interface Repository {
  createUser(user: User): Promise<void>;
  findUserByEmail(email: string): Promise<User | undefined>;
  findUserById(id: string): Promise<User | undefined>;
  createCountry(country: Country): Promise<void>;
  findCountryById(id: string): Promise<Country | undefined>;
  findCountryByUserId(userId: string): Promise<Country | undefined>;
  listCountries(): Promise<Country[]>;
  updateCountry(id: string, fn: (current: Country) => Country): Promise<Country>;
}
