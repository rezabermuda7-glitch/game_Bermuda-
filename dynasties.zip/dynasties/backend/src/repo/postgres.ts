// NOTE: requires `pg` and a running Postgres (not run in the authoring sandbox — see README "Verification status").
import { readFileSync } from 'node:fs';
import pg from 'pg';
import { AppError } from '../errors.ts';
import type { Country, Repository, User } from './types.ts';

const UNIQUE_VIOLATION = '23505';
const CONSTRAINT_CODES: Record<string, string> = {
  users_email_key: 'email_taken',
  countries_user_id_key: 'country_exists',
  countries_name_lower_idx: 'name_taken',
};

function mapError(err: unknown): never {
  const e = err as { code?: string; constraint?: string };
  if (e?.code === UNIQUE_VIOLATION && e.constraint && CONSTRAINT_CODES[e.constraint]) {
    throw new AppError(409, CONSTRAINT_CODES[e.constraint]);
  }
  throw err;
}

function rowToUser(r: any): User {
  return { id: r.id, email: r.email, passwordHash: r.password_hash, createdAt: Number(r.created_at) };
}

function rowToCountry(r: any): Country {
  return {
    id: r.id,
    userId: r.user_id,
    name: r.name,
    dynasty: r.dynasty,
    color: r.color,
    flag: r.flag,
    x: r.x,
    y: r.y,
    createdAt: Number(r.created_at),
    treasury: {
      stock: { food: r.food, ammo: r.ammo, troops: r.troops },
      lastUpdatedAt: Number(r.treasury_updated_at),
    },
    bases: r.bases,
  };
}

export class PostgresRepository implements Repository {
  private pool: pg.Pool;

  constructor(connectionString: string) {
    this.pool = new pg.Pool({ connectionString });
  }

  async migrate(): Promise<void> {
    const sql = readFileSync(new URL('../db/schema.sql', import.meta.url), 'utf8');
    await this.pool.query(sql);
  }

  async close(): Promise<void> {
    await this.pool.end();
  }

  async createUser(u: User): Promise<void> {
    try {
      await this.pool.query(
        'INSERT INTO users (id, email, password_hash, created_at) VALUES ($1,$2,$3,$4)',
        [u.id, u.email, u.passwordHash, u.createdAt],
      );
    } catch (e) {
      mapError(e);
    }
  }

  async findUserByEmail(email: string) {
    const r = await this.pool.query('SELECT * FROM users WHERE email = $1', [email]);
    return r.rows[0] ? rowToUser(r.rows[0]) : undefined;
  }

  async findUserById(id: string) {
    const r = await this.pool.query('SELECT * FROM users WHERE id = $1', [id]);
    return r.rows[0] ? rowToUser(r.rows[0]) : undefined;
  }

  async createCountry(c: Country): Promise<void> {
    try {
      await this.pool.query(
        `INSERT INTO countries
           (id, user_id, name, dynasty, color, flag, x, y, food, ammo, troops, treasury_updated_at, bases, created_at)
         VALUES ($1,$2,$3,$4,$5,$6,$7,$8,$9,$10,$11,$12,$13,$14)`,
        [
          c.id, c.userId, c.name, c.dynasty, c.color, c.flag, c.x, c.y,
          c.treasury.stock.food, c.treasury.stock.ammo, c.treasury.stock.troops,
          c.treasury.lastUpdatedAt, JSON.stringify(c.bases), c.createdAt,
        ],
      );
    } catch (e) {
      mapError(e);
    }
  }

  async findCountryById(id: string) {
    const r = await this.pool.query('SELECT * FROM countries WHERE id = $1', [id]);
    return r.rows[0] ? rowToCountry(r.rows[0]) : undefined;
  }

  async findCountryByUserId(userId: string) {
    const r = await this.pool.query('SELECT * FROM countries WHERE user_id = $1', [userId]);
    return r.rows[0] ? rowToCountry(r.rows[0]) : undefined;
  }

  async listCountries() {
    const r = await this.pool.query('SELECT * FROM countries ORDER BY created_at');
    return r.rows.map(rowToCountry);
  }

  /** Row lock (SELECT ... FOR UPDATE) makes the read-modify-write atomic across processes. */
  async updateCountry(id: string, fn: (current: Country) => Country): Promise<Country> {
    const client = await this.pool.connect();
    try {
      await client.query('BEGIN');
      const r = await client.query('SELECT * FROM countries WHERE id = $1 FOR UPDATE', [id]);
      if (!r.rows[0]) throw new AppError(404, 'country_not_found');
      const next = fn(rowToCountry(r.rows[0]));
      await client.query(
        `UPDATE countries SET food=$2, ammo=$3, troops=$4, treasury_updated_at=$5, bases=$6 WHERE id=$1`,
        [
          id, next.treasury.stock.food, next.treasury.stock.ammo, next.treasury.stock.troops,
          next.treasury.lastUpdatedAt, JSON.stringify(next.bases),
        ],
      );
      await client.query('COMMIT');
      return next;
    } catch (e) {
      await client.query('ROLLBACK').catch(() => undefined);
      throw e;
    } finally {
      client.release();
    }
  }
}
