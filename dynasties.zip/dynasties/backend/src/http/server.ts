import http from 'node:http';
import type { IncomingMessage, Server, ServerResponse } from 'node:http';
import { AppError } from '../errors.ts';
import { verifyJwt } from '../modules/auth/jwt.ts';
import type { AuthService } from '../modules/auth/auth.service.ts';
import type { CountryService } from '../modules/country/country.service.ts';
import type { GameService } from '../modules/base/game.service.ts';
import type { MapService } from '../modules/map/map.service.ts';
import { RateLimiter } from './rate-limit.ts';

export interface HttpDeps {
  auth: AuthService;
  countries: CountryService;
  game: GameService;
  map: MapService;
  jwtSecret: string;
  corsOrigin: string;
  clock?: () => number;
  authRateLimit?: { max: number; windowMs: number };
}

const MAX_BODY = 16 * 1024;

async function readJson(req: IncomingMessage): Promise<unknown> {
  const chunks: Buffer[] = [];
  let size = 0;
  for await (const chunk of req) {
    size += (chunk as Buffer).length;
    if (size > MAX_BODY) throw new AppError(413, 'body_too_large');
    chunks.push(chunk as Buffer);
  }
  if (size === 0) return {};
  try {
    return JSON.parse(Buffer.concat(chunks).toString('utf8'));
  } catch {
    throw new AppError(400, 'invalid_json');
  }
}

function send(res: ServerResponse, status: number, body: unknown): void {
  const data = JSON.stringify(body);
  res.writeHead(status, {
    'content-type': 'application/json; charset=utf-8',
    'content-length': Buffer.byteLength(data),
  });
  res.end(data);
}

export function createHttpServer(deps: HttpDeps): Server {
  const clock = deps.clock ?? Date.now;
  const limiter = new RateLimiter(
    deps.authRateLimit?.max ?? 20,
    deps.authRateLimit?.windowMs ?? 60_000,
    clock,
  );

  const userIdFrom = (req: IncomingMessage): string => {
    const header = req.headers.authorization ?? '';
    const match = /^Bearer (.+)$/.exec(header);
    if (!match) throw new AppError(401, 'missing_token');
    return verifyJwt(match[1], deps.jwtSecret, clock()).sub;
  };

  async function route(req: IncomingMessage, res: ServerResponse): Promise<void> {
    const url = new URL(req.url ?? '/', 'http://localhost');
    const path = url.pathname;
    const method = req.method ?? 'GET';

    if (method === 'GET' && path === '/health') return send(res, 200, { ok: true });

    if (method === 'POST' && (path === '/api/auth/register' || path === '/api/auth/login')) {
      if (!limiter.allow(req.socket.remoteAddress ?? 'unknown')) throw new AppError(429, 'rate_limited');
      const body = await readJson(req);
      const out = path.endsWith('register') ? await deps.auth.register(body) : await deps.auth.login(body);
      return send(res, path.endsWith('register') ? 201 : 200, out);
    }

    if (method === 'GET' && path === '/api/map') {
      userIdFrom(req);
      return send(res, 200, await deps.map.snapshot());
    }

    if (path === '/api/country') {
      const userId = userIdFrom(req);
      if (method === 'GET') return send(res, 200, await deps.game.getState(userId));
      if (method === 'POST') {
        await deps.countries.create(userId, await readJson(req));
        return send(res, 201, await deps.game.getState(userId));
      }
    }

    const upgrade = /^\/api\/country\/bases\/(\d+)\/upgrade$/.exec(path);
    if (method === 'POST' && upgrade) {
      const userId = userIdFrom(req);
      return send(res, 200, await deps.game.upgrade(userId, Number(upgrade[1])));
    }

    throw new AppError(404, 'not_found');
  }

  return http.createServer((req, res) => {
    res.setHeader('access-control-allow-origin', deps.corsOrigin);
    res.setHeader('access-control-allow-headers', 'authorization, content-type');
    res.setHeader('access-control-allow-methods', 'GET, POST, OPTIONS');
    res.setHeader('vary', 'origin');
    if (req.method === 'OPTIONS') {
      res.writeHead(204);
      res.end();
      return;
    }
    route(req, res).catch((err: unknown) => {
      if (res.headersSent) return res.end();
      if (err instanceof AppError) return send(res, err.status, { error: err.code });
      console.error('Unhandled error:', err);
      send(res, 500, { error: 'internal' });
    });
  });
}
