/** Fixed-window in-memory limiter. Phase 2 moves this to Redis so it works across processes. */
export class RateLimiter {
  private hits = new Map<string, { count: number; resetAt: number }>();
  private max: number;
  private windowMs: number;
  private clock: () => number;

  constructor(max: number, windowMs: number, clock: () => number = Date.now) {
    this.max = max;
    this.windowMs = windowMs;
    this.clock = clock;
  }

  allow(key: string): boolean {
    const now = this.clock();
    if (this.hits.size > 10_000) {
      for (const [k, v] of this.hits) if (v.resetAt <= now) this.hits.delete(k);
    }
    const entry = this.hits.get(key);
    if (!entry || entry.resetAt <= now) {
      this.hits.set(key, { count: 1, resetAt: now + this.windowMs });
      return true;
    }
    entry.count += 1;
    return entry.count <= this.max;
  }
}
