// NOTE: requires `socket.io` (not yet installed/run in the authoring sandbox — see README "Verification status").
import { Server } from 'socket.io';
import type { Server as HttpServer } from 'node:http';
import type { Bus, CountryCreatedEvent } from '../bus.ts';
import { AppError } from '../errors.ts';
import { verifyJwt } from '../modules/auth/jwt.ts';
import type { GameService } from '../modules/base/game.service.ts';
import type { Repository } from '../repo/types.ts';

export interface RealtimeDeps {
  httpServer: HttpServer;
  jwtSecret: string;
  corsOrigin: string;
  repo: Repository;
  game: GameService;
  bus: Bus;
}

/**
 * Rooms:  map            – everyone (public map updates)
 *         user:{userId}  – all sockets of one player
 *         country:{id}   – the owner's sockets; receives private state
 * Server -> client: state:snapshot, map:country_added
 * Client -> server: base:upgrade({ index }, ack)
 */
export function attachRealtime(deps: RealtimeDeps): Server {
  const io = new Server(deps.httpServer, { cors: { origin: deps.corsOrigin } });

  io.use((socket, next) => {
    try {
      socket.data.userId = verifyJwt(socket.handshake.auth?.token, deps.jwtSecret).sub;
      next();
    } catch {
      next(new Error('unauthorized'));
    }
  });

  io.on('connection', async (socket) => {
    const userId: string = socket.data.userId;
    socket.join('map');
    socket.join(`user:${userId}`);

    const country = await deps.repo.findCountryByUserId(userId);
    if (country) {
      socket.join(`country:${country.id}`);
      const view = await deps.game.getStateByCountryId(country.id);
      if (view) socket.emit('state:snapshot', view);
    }

    socket.on('base:upgrade', async (payload: { index?: unknown }, ack?: (r: unknown) => void) => {
      try {
        const state = await deps.game.upgrade(userId, payload?.index);
        ack?.({ ok: true, state });
      } catch (err) {
        if (err instanceof AppError) ack?.({ ok: false, code: err.code });
        else {
          console.error('socket upgrade failed:', err);
          ack?.({ ok: false, code: 'internal' });
        }
      }
    });
  });

  deps.bus.on('country:created', async ({ country, userId }: CountryCreatedEvent) => {
    io.to('map').emit('map:country_added', country);
    io.in(`user:${userId}`).socketsJoin(`country:${country.id}`);
    const view = await deps.game.getStateByCountryId(country.id);
    if (view) io.to(`user:${userId}`).emit('state:snapshot', view);
  });

  deps.bus.on('country:updated', async ({ countryId }: { countryId: string }) => {
    const view = await deps.game.getStateByCountryId(countryId);
    if (view) io.to(`country:${countryId}`).emit('state:snapshot', view);
  });

  return io;
}
