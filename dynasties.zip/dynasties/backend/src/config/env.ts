export interface Config {
  port: number;
  jwtSecret: string;
  jwtTtlSec: number;
  databaseUrl?: string;
  corsOrigin: string;
}

export function loadConfig(env: Record<string, string | undefined> = process.env): Config {
  const production = env.NODE_ENV === 'production';
  const jwtSecret = env.JWT_SECRET ?? (production ? '' : 'dev-only-secret-change-me');
  if (jwtSecret.length < 16) {
    throw new Error('JWT_SECRET must be set (min 16 chars) in production');
  }
  const port = Number(env.PORT ?? 4000);
  if (!Number.isInteger(port) || port < 0 || port > 65535) throw new Error('Invalid PORT');
  return {
    port,
    jwtSecret,
    jwtTtlSec: Number(env.JWT_TTL_SEC ?? 7 * 24 * 3600),
    databaseUrl: env.DATABASE_URL,
    corsOrigin: env.CORS_ORIGIN ?? 'http://localhost:3000',
  };
}
