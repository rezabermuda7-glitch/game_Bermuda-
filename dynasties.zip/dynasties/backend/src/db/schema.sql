CREATE TABLE IF NOT EXISTS users (
  id            uuid PRIMARY KEY,
  email         text NOT NULL,
  password_hash text NOT NULL,
  created_at    bigint NOT NULL,
  CONSTRAINT users_email_key UNIQUE (email)
);

CREATE TABLE IF NOT EXISTS countries (
  id                  uuid PRIMARY KEY,
  user_id             uuid NOT NULL REFERENCES users(id),
  name                text NOT NULL,
  dynasty             text NOT NULL,
  color               text NOT NULL,
  flag                text NOT NULL,
  x                   integer NOT NULL,
  y                   integer NOT NULL,
  food                double precision NOT NULL,
  ammo                double precision NOT NULL,
  troops              double precision NOT NULL,
  treasury_updated_at bigint NOT NULL,
  bases               jsonb NOT NULL,
  created_at          bigint NOT NULL,
  CONSTRAINT countries_user_id_key UNIQUE (user_id)
);

CREATE UNIQUE INDEX IF NOT EXISTS countries_name_lower_idx ON countries (lower(name));
