import { EventEmitter } from 'node:events';
import type { PublicCountry } from './modules/country/country.service.ts';

/**
 * Domain events, consumed by the realtime layer:
 *  - country:created  { country, userId }
 *  - country:updated  { countryId }
 */
export type Bus = EventEmitter;

export function createBus(): Bus {
  return new EventEmitter();
}

export interface CountryCreatedEvent {
  country: PublicCountry;
  userId: string;
}
