import { randomUUID } from 'node:crypto';
import { placeCountry, STARTING_STOCK } from '@dynasties/game-core';
import type { BaseState } from '@dynasties/game-core';
import type { Bus } from '../../bus.ts';
import { AppError } from '../../errors.ts';
import type { Country, Repository } from '../../repo/types.ts';

export interface PublicCountry {
  id: string;
  name: string;
  dynasty: string;
  color: string;
  flag: string;
  x: number;
  y: number;
}

export function toPublic(c: Country): PublicCountry {
  return { id: c.id, name: c.name, dynasty: c.dynasty, color: c.color, flag: c.flag, x: c.x, y: c.y };
}

function text(v: unknown, min: number, max: number, field: string, re?: RegExp): string {
  const s = typeof v === 'string' ? v.trim().replace(/\s+/g, ' ') : '';
  if (s.length < min || s.length > max || (re && !re.test(s))) {
    throw new AppError(400, `invalid_${field}`);
  }
  return s;
}

const NAME_RE = /^[\p{L}\p{N} '\-]+$/u;
const COLOR_RE = /^#[0-9a-fA-F]{6}$/;
const FLAG_RE = /^[^<>&"'`\s]+$/u;

export const INITIAL_BASES: BaseState[] = [
  { kind: 'fortress', level: 1 },
  { kind: 'farm', level: 1 },
  { kind: 'armory', level: 1 },
  { kind: 'barracks', level: 1 },
];

export class CountryService {
  private repo: Repository;
  private bus: Bus;
  private clock: () => number;
  private rand: () => number;
  private queue: Promise<unknown> = Promise.resolve();

  constructor(repo: Repository, bus: Bus, clock: () => number = Date.now, rand: () => number = Math.random) {
    this.repo = repo;
    this.bus = bus;
    this.clock = clock;
    this.rand = rand;
  }

  /** Creations are serialized so two players can never be given overlapping spots. */
  create(userId: string, input: unknown): Promise<Country> {
    const run = this.queue.then(() => this.doCreate(userId, input));
    this.queue = run.catch(() => undefined);
    return run;
  }

  private async doCreate(userId: string, input: unknown): Promise<Country> {
    const body = (input ?? {}) as Record<string, unknown>;
    const name = text(body.name, 3, 24, 'name', NAME_RE);
    const dynasty = text(body.dynasty, 2, 32, 'dynasty', NAME_RE);
    const color = text(body.color, 7, 7, 'color', COLOR_RE).toLowerCase();
    const flag = text(body.flag, 1, 8, 'flag', FLAG_RE);

    if (await this.repo.findCountryByUserId(userId)) throw new AppError(409, 'country_exists');

    const existing = await this.repo.listCountries();
    const spot = placeCountry(existing, this.rand);
    if (!spot) throw new AppError(503, 'map_full', 'No free land left on the map');

    const now = this.clock();
    const country: Country = {
      id: randomUUID(),
      userId,
      name,
      dynasty,
      color,
      flag,
      x: spot.x,
      y: spot.y,
      createdAt: now,
      treasury: { stock: { ...STARTING_STOCK }, lastUpdatedAt: now },
      bases: INITIAL_BASES.map((b) => ({ ...b })),
    };
    await this.repo.createCountry(country);
    this.bus.emit('country:created', { country: toPublic(country), userId });
    return country;
  }
}
