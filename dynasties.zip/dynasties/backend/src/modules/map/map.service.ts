import { MAP_SIZE } from '@dynasties/game-core';
import type { Repository } from '../../repo/types.ts';
import { toPublic } from '../country/country.service.ts';
import type { PublicCountry } from '../country/country.service.ts';

export class MapService {
  private repo: Repository;
  constructor(repo: Repository) {
    this.repo = repo;
  }

  /** Public data only: never exposes treasuries or owners. */
  async snapshot(): Promise<{ size: number; countries: PublicCountry[] }> {
    const all = await this.repo.listCountries();
    return { size: MAP_SIZE, countries: all.map(toPublic) };
  }
}
