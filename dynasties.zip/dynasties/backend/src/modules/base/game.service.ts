import {
  MAX_LEVEL,
  settleCountry,
  totalCaps,
  totalRates,
  tryUpgradeBase,
  upgradeCost,
} from '@dynasties/game-core';
import type { Stock } from '@dynasties/game-core';
import type { Bus } from '../../bus.ts';
import { AppError } from '../../errors.ts';
import type { Country, Repository } from '../../repo/types.ts';
import { toPublic } from '../country/country.service.ts';
import type { PublicCountry } from '../country/country.service.ts';

export interface CountryView {
  country: PublicCountry;
  /** Server time the numbers are valid for; clients extrapolate with ratesPerHour. */
  serverTime: number;
  stock: Stock;
  ratesPerHour: Stock;
  caps: Stock;
  bases: {
    index: number;
    kind: string;
    level: number;
    maxLevel: number;
    upgradeCost: { food: number; ammo: number } | null;
  }[];
}

export function buildView(c: Country, now: number): CountryView {
  const settled = settleCountry(c.treasury, c.bases, now);
  return {
    country: toPublic(c),
    serverTime: settled.lastUpdatedAt,
    stock: settled.stock,
    ratesPerHour: totalRates(c.bases),
    caps: totalCaps(c.bases),
    bases: c.bases.map((b, index) => ({
      index,
      kind: b.kind,
      level: b.level,
      maxLevel: MAX_LEVEL,
      upgradeCost: b.level < MAX_LEVEL ? upgradeCost(b.kind, b.level) : null,
    })),
  };
}

const REASON_STATUS = { not_found: 404, max_level: 409, insufficient_resources: 409 } as const;

export class GameService {
  private repo: Repository;
  private bus: Bus;
  private clock: () => number;

  constructor(repo: Repository, bus: Bus, clock: () => number = Date.now) {
    this.repo = repo;
    this.bus = bus;
    this.clock = clock;
  }

  async getState(userId: string): Promise<CountryView> {
    const c = await this.repo.findCountryByUserId(userId);
    if (!c) throw new AppError(404, 'no_country');
    return buildView(c, this.clock());
  }

  async getStateByCountryId(countryId: string): Promise<CountryView | undefined> {
    const c = await this.repo.findCountryById(countryId);
    return c ? buildView(c, this.clock()) : undefined;
  }

  async upgrade(userId: string, index: unknown): Promise<CountryView> {
    if (typeof index !== 'number' || !Number.isInteger(index) || index < 0) {
      throw new AppError(400, 'invalid_base');
    }
    const owned = await this.repo.findCountryByUserId(userId);
    if (!owned) throw new AppError(404, 'no_country');

    const updated = await this.repo.updateCountry(owned.id, (c) => {
      const r = tryUpgradeBase(c.treasury, c.bases, index, this.clock());
      if (!r.ok) throw new AppError(REASON_STATUS[r.reason], r.reason);
      return { ...c, bases: r.bases, treasury: r.treasury };
    });
    this.bus.emit('country:updated', { countryId: updated.id });
    return buildView(updated, this.clock());
  }
}
