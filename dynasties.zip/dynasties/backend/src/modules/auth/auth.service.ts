import { randomUUID } from 'node:crypto';
import { AppError } from '../../errors.ts';
import type { Repository } from '../../repo/types.ts';
import { signJwt } from './jwt.ts';
import { hashPassword, verifyPassword } from './password.ts';

const EMAIL_RE = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
// Hash of a throwaway password; verified against when the email is unknown so timing doesn't leak existence.
const DUMMY_HASH_PROMISE = hashPassword('dummy-password-for-timing');

export class AuthService {
  private repo: Repository;
  private secret: string;
  private ttlSec: number;
  private clock: () => number;

  constructor(repo: Repository, secret: string, ttlSec: number, clock: () => number = Date.now) {
    this.repo = repo;
    this.secret = secret;
    this.ttlSec = ttlSec;
    this.clock = clock;
  }

  private parse(input: unknown): { email: string; password: string } {
    const body = (input ?? {}) as Record<string, unknown>;
    const email = typeof body.email === 'string' ? body.email.trim().toLowerCase() : '';
    const password = typeof body.password === 'string' ? body.password : '';
    if (email.length > 254 || !EMAIL_RE.test(email)) throw new AppError(400, 'invalid_email');
    if (password.length < 8 || password.length > 128) throw new AppError(400, 'invalid_password');
    return { email, password };
  }

  private token(userId: string): string {
    return signJwt(userId, this.secret, this.ttlSec, this.clock());
  }

  async register(input: unknown): Promise<{ token: string }> {
    const { email, password } = this.parse(input);
    const id = randomUUID();
    await this.repo.createUser({
      id,
      email,
      passwordHash: await hashPassword(password),
      createdAt: this.clock(),
    });
    return { token: this.token(id) };
  }

  async login(input: unknown): Promise<{ token: string }> {
    const { email, password } = this.parse(input);
    const user = await this.repo.findUserByEmail(email);
    const ok = await verifyPassword(password, user ? user.passwordHash : await DUMMY_HASH_PROMISE);
    if (!user || !ok) throw new AppError(401, 'invalid_credentials');
    return { token: this.token(user.id) };
  }
}
