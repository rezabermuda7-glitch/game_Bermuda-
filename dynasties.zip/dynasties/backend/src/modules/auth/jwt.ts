import { createHmac, timingSafeEqual } from 'node:crypto';
import { AppError } from '../../errors.ts';

const b64 = (v: Buffer | string) => Buffer.from(v).toString('base64url');
/** Pinned header: tokens with any other header (including alg "none") are rejected. */
const HEADER = b64(JSON.stringify({ alg: 'HS256', typ: 'JWT' }));

function mac(data: string, secret: string): Buffer {
  return createHmac('sha256', secret).update(data).digest();
}

export function signJwt(sub: string, secret: string, ttlSec: number, nowMs = Date.now()): string {
  const iat = Math.floor(nowMs / 1000);
  const payload = b64(JSON.stringify({ sub, iat, exp: iat + ttlSec }));
  return `${HEADER}.${payload}.${b64(mac(`${HEADER}.${payload}`, secret))}`;
}

export function verifyJwt(token: unknown, secret: string, nowMs = Date.now()): { sub: string } {
  const bad = () => new AppError(401, 'invalid_token', 'Invalid or expired token');
  const parts = typeof token === 'string' ? token.split('.') : [];
  if (parts.length !== 3) throw bad();
  const [h, p, s] = parts;
  if (h !== HEADER) throw bad();
  const expected = mac(`${h}.${p}`, secret);
  const given = Buffer.from(s, 'base64url');
  if (given.length !== expected.length || !timingSafeEqual(given, expected)) throw bad();
  let payload: { sub?: unknown; exp?: unknown };
  try {
    payload = JSON.parse(Buffer.from(p, 'base64url').toString('utf8'));
  } catch {
    throw bad();
  }
  if (typeof payload.sub !== 'string' || typeof payload.exp !== 'number') throw bad();
  if (payload.exp <= nowMs / 1000) throw bad();
  return { sub: payload.sub };
}
