import { createBus } from './bus.ts';
import { loadConfig } from './config/env.ts';
import { createHttpServer } from './http/server.ts';
import { AuthService } from './modules/auth/auth.service.ts';
import { GameService } from './modules/base/game.service.ts';
import { CountryService } from './modules/country/country.service.ts';
import { MapService } from './modules/map/map.service.ts';
import { MemoryRepository } from './repo/memory.ts';
import type { Repository } from './repo/types.ts';

const config = loadConfig();
const bus = createBus();

let repo: Repository;
let closeDb: () => Promise<void> = async () => {};
if (config.databaseUrl) {
  const { PostgresRepository } = await import('./repo/postgres.ts');
  const pgRepo = new PostgresRepository(config.databaseUrl);
  await pgRepo.migrate();
  repo = pgRepo;
  closeDb = () => pgRepo.close();
  console.log('Using Postgres');
} else {
  repo = new MemoryRepository();
  console.warn('DATABASE_URL not set: using IN-MEMORY storage (data is lost on restart)');
}

const game = new GameService(repo, bus);
const server = createHttpServer({
  auth: new AuthService(repo, config.jwtSecret, config.jwtTtlSec),
  countries: new CountryService(repo, bus),
  game,
  map: new MapService(repo),
  jwtSecret: config.jwtSecret,
  corsOrigin: config.corsOrigin,
});

const { attachRealtime } = await import('./realtime/socket.ts');
const io = attachRealtime({
  httpServer: server,
  jwtSecret: config.jwtSecret,
  corsOrigin: config.corsOrigin,
  repo,
  game,
  bus,
});

server.listen(config.port, () => console.log(`Dynasties backend listening on :${config.port}`));

async function shutdown() {
  io.close();
  server.close();
  await closeDb();
  process.exit(0);
}
process.on('SIGINT', shutdown);
process.on('SIGTERM', shutdown);
