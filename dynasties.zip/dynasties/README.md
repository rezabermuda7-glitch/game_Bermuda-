# سلسله‌ها: جنگ مرزها (Dynasties: Border Wars)

بازی استراتژی همزمان چندنفره: هر پلیر کشور و سلسله‌ی خودش را می‌سازد، پایگاه‌ها را ارتقا می‌دهد و منابع (غذا، مهمات، نیرو) خودکار و به مرور زمان تولید می‌شوند. نیرو با پول خریده نمی‌شود.

معماری: [docs/ARCHITECTURE.md](docs/ARCHITECTURE.md) · نقشه‌ی راه: [docs/ROADMAP.md](docs/ROADMAP.md)

## وضعیت فعلی: فاز ۱ (MVP)

ساخت کشور و سلسله (نام، رنگ، پرچم)، ثبت‌نام/ورود با JWT، چهار پایگاه با ارتقا (هزینه از منابع خود بازی‌کن)، تولید آفلاین‌پذیر با درآمد پایه، نقشه‌ی مشترک با فاصله‌ی حداقلی بین کشورها، و به‌روزرسانی زنده با Socket.io.

## وضعیت راستی‌آزمایی (مهم)

| بخش | وضعیت |
|---|---|
| هسته‌ی قوانین (`packages/game-core`) | ✅ ۱۷ تست اجرا و پاس شد |
| بک‌اند: auth، سرویس‌ها، HTTP API، rate-limit | ✅ ۳۸ تست اجرا و پاس شد (روی مخزن in-memory) |
| Socket.io (`backend/src/realtime/socket.ts`) | ⚠️ نوشته شده، هنوز اجرا نشده |
| Postgres (`backend/src/repo/postgres.ts`، `schema.sql`) | ⚠️ نوشته شده، هنوز اجرا نشده |
| فرانت‌اند Next.js | ⚠️ نوشته شده، هنوز build/اجرا نشده |
| Redis | ⏳ فاز ۲ |

بخش‌های ⚠️ در محیط ساخت قابل نصب/اجرا نبودند (دسترسی به registry پکیج‌ها بسته بود). بار اول که اجرا می‌کنید ممکن است خطای کوچک تایپ یا import داشته باشند؛ اگر پیش آمد، متن خطا را بفرستید تا رفع کنم.

## اجرا

پیش‌نیاز: Node.js ‏22.18 یا بالاتر (برای اجرای مستقیم TypeScript)، Docker (برای Postgres).

```bash
npm install
docker compose up -d                       # Postgres و Redis

cp backend/.env.example backend/.env       # JWT_SECRET را عوض کنید
cp frontend/.env.local.example frontend/.env.local

# بک‌اند (پورت ۴۰۰۰)
cd backend && node --env-file=.env src/main.ts

# فرانت‌اند (پورت ۳۰۰۰) در ترمینال دیگر
cd frontend && npm run dev
```

بدون `DATABASE_URL` بک‌اند با حافظه‌ی موقت اجرا می‌شود (با ری‌استارت داده پاک می‌شود).

## تست

```bash
npm test                                   # هسته + بک‌اند
```

تست‌ها با ابزار داخلی Node (`node:test`) نوشته شده‌اند و پکیج اضافه نمی‌خواهند.

## API

| مسیر | توضیح |
|---|---|
| `POST /api/auth/register` · `/login` | `{email, password}` ← `{token}` |
| `POST /api/country` | `{name, dynasty, color, flag}` |
| `GET /api/country` | وضعیت کشور خودم (منابع، نرخ، سقف، پایگاه‌ها) |
| `POST /api/country/bases/:index/upgrade` | ارتقای پایگاه |
| `GET /api/map` | نقشه‌ی عمومی (بدون اطلاعات خصوصی) |

Socket.io: توکن در `auth.token`. رویدادها: `state:snapshot`، `map:country_added`، و `base:upgrade` از کلاینت.

## نکات طراحی

- تولید منابع tick ندارد؛ هر بار از زمان سپری‌شده محاسبه می‌شود، پس پلیر آفلاین بدون هزینه به تولید ادامه می‌دهد.
- ارتقاها در دیتابیس با قفل ردیف (`FOR UPDATE`) اتمیک‌اند، بنابراین دو درخواست همزمان نمی‌توانند دوبار خرج کنند (تست رقابت دارد).
- JWT از نوع HS256 با `crypto` خود Node پیاده شده و header ثابت دارد (alg:none رد می‌شود). در صورت تمایل می‌توان با `jsonwebtoken` جایگزین کرد.
- توکن فرانت‌اند در `localStorage` است؛ انتقال به کوکی httpOnly در فاز ۲ برنامه‌ریزی شده.
